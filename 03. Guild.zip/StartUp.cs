﻿using System;
using System.Linq;

namespace Guild
{
   public class StartUp
    {
        static void Main(string[] args)
        {
            Guild guild = new Guild("Weekend Raiders", 20);
            Player player = new Player("Mark", "Rogue");
            Console.WriteLine(player);

            //Add player
            guild.AddPlayer(player);
            Console.WriteLine(guild.Count);
            Console.WriteLine(guild.RemovePlayer("Gosho"));

            Player firstPlayer = new Player("Pep", "Warrior"); 
            Player secondPlayer = new Player("Lizzy", "Priest"); 
            Player thirdPlayer = new Player("Mike", "Rogue"); 
            Player fourthPlayer = new Player("Marlin", "Mage");

            //Add description to player
            secondPlayer.Description = "Best healer EU";

            //Add players
            guild.AddPlayer(firstPlayer); 
            guild.AddPlayer(secondPlayer); 
            guild.AddPlayer(thirdPlayer); 
            guild.AddPlayer(fourthPlayer);

            //Promote player
            guild.PromotePlayer("Lizzy");

            //RemovePlayer
            Console.WriteLine(guild.RemovePlayer("Pep"));

            Player[] kickedPlayers = guild.KickPlayersByClass("Rogue");

            Console.WriteLine(string.Join(", ", kickedPlayers.Select(p => p.Name)));
            Console.WriteLine(guild.Report());

        }
    }
}
